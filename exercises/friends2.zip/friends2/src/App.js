import React from 'react';
import './App.css';
import data from './data'
import Friend from './Friends/Friend'



const FriendsList = () => data.map((friend,index) => 
<Friend
    name = {friend.name}
    age = {friend.age}
    pets = {friend.pets}
    key = {index}
    />)

function App() {
  return (
    <div className="App" style={{
        justifyContent: "center",
        display: "flex",
        flexWrap: "wrap",
    }}>
      <FriendsList />
    </div>
  );
}

export default App;
