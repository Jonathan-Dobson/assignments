import React from 'react';
import {WithState} from '../../StateProvider'

export default WithState(()=><div>
        Display
        
    </div>
)