

export const darkSkyKey = '25f5a82c3e4c8f2953e32e76561913e1';